from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=80)
    annotation = models.CharField(max_length=120)
    author = models.CharField(max_length=80)
    publication_year = models.IntegerField()